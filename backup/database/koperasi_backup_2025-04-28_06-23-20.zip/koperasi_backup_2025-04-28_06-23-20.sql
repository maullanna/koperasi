#
# TABLE STRUCTURE FOR: absensi
#

DROP TABLE IF EXISTS `absensi`;

CREATE TABLE `absensi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_karyawan` int NOT NULL,
  `tanggal` date NOT NULL,
  `jam_masuk` time DEFAULT NULL,
  `jam_pulang` time DEFAULT NULL,
  `status` enum('hadir') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'hadir',
  `keterangan` text COLLATE utf8mb4_general_ci,
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_absen` (`id_karyawan`,`tanggal`),
  CONSTRAINT `absensi_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `absensi` (`id`, `id_karyawan`, `tanggal`, `jam_masuk`, `jam_pulang`, `status`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (2, 25, '2025-04-27', '06:50:00', '04:50:00', '', 'Sudah pulang', '2025-04-27 00:45:49', '2025-04-27 00:45:49');
INSERT INTO `absensi` (`id`, `id_karyawan`, `tanggal`, `jam_masuk`, `jam_pulang`, `status`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (3, 4, '2025-04-27', '09:30:00', '17:00:00', '', 'hadir', '2025-04-27 14:16:03', '2025-04-27 14:16:03');
INSERT INTO `absensi` (`id`, `id_karyawan`, `tanggal`, `jam_masuk`, `jam_pulang`, `status`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (4, 26, '2025-04-28', '07:35:00', '17:28:00', 'hadir', 'Absen dulu ', '2025-04-28 07:45:12', '2025-04-28 07:45:12');
INSERT INTO `absensi` (`id`, `id_karyawan`, `tanggal`, `jam_masuk`, `jam_pulang`, `status`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (5, 26, '2025-04-29', '07:06:00', '17:04:00', 'hadir', 'Kerja Bagus', '2025-04-28 09:00:43', '2025-04-28 09:00:43');


#
# TABLE STRUCTURE FOR: bpjs
#

DROP TABLE IF EXISTS `bpjs`;

CREATE TABLE `bpjs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_karyawan` int NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `keterangan` text COLLATE utf8mb4_general_ci,
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `bpjs_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `bpjs` (`id`, `id_karyawan`, `tanggal`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (1, 2, '2025-04-20', '560000.00', '', '2025-04-20 14:19:00', '2025-04-20 14:19:00');


#
# TABLE STRUCTURE FOR: karyawan
#

DROP TABLE IF EXISTS `karyawan`;

CREATE TABLE `karyawan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `nama_karyawan` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `no_hp` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_general_ci,
  `saldo_kasbon` decimal(15,2) DEFAULT '0.00',
  `saldo_tabungan` decimal(15,2) DEFAULT '0.00',
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_general_ci DEFAULT 'aktif',
  `role` enum('owner','admin','karyawan') COLLATE utf8mb4_general_ci DEFAULT 'karyawan',
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nik` (`nik`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (2, '321', 'Agus hari murti', 'agus', '$2y$10$IbDh7n5aunJSYJCNgvQIoePOeQt9De7uyX.XZgYPXIy7XxwWCXavq', '0', 'karawang', '400150.00', '300000.00', 'aktif', 'karyawan', '2025-04-20 11:17:30', '2025-04-27 20:33:43');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (4, '222', 'hohmat', 'rohmat', '$2y$10$y/wCScXwN.xlFjq/i1yBAOgg5gV3rDXIYMRZr/WhSQ5pPB0YbWxvy', '0', 'karawang', '0.00', '0.00', 'aktif', 'karyawan', '2025-04-20 17:51:39', '2025-04-26 23:11:58');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (5, '2', '200', 'uli', '$2y$10$mWTr4v8Rngbnl8eP2/MAru6Byd3XrBZSwoE0qNLqObtTQzHlLIaRS', '08123456789', NULL, '0.00', '0.00', 'aktif', 'admin', '2025-04-23 15:19:07', '2025-04-26 22:16:00');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (11, '100', 'ule', 'aaaa', '$2y$10$yq939njqcSTOrsLHPvs7ie4mkv8/g8PVbq.dzdoImvxNv8kA6csAm', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-23 15:55:39', '2025-04-23 15:55:39');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (12, '200', 'uli', 'bbbb', '$2y$10$5VDsaZN4f2YAU9FXnsRa0uFeeiBM10FdKVXRNin12R3LLtv7zyTPe', 'Admin', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-23 15:55:39', '2025-04-23 15:55:39');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (13, '300', 'ulo', 'cccc', '$2y$10$JY0GU7GzV14s9ochQgjv5uG2NruszuA/S1Bo2.EuzTtJbjT.l3bSW', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-23 15:55:39', '2025-04-23 15:55:39');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (14, '400', 'ucu', 'dddd', '$2y$10$vG9y044ghyL46E0LPNlbuOdngGQYLskZrgdSFmmOI9zxFTZriN68y', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-23 15:55:39', '2025-04-23 15:55:39');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (15, '500', 'uci', 'eeee', '$2y$10$.T55MYrb/On4MvEU3/o.Pu38MQJJMSHbrdUckoJmYic1PQfTCEQ7C', 'Admin', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-23 15:55:39', '2025-04-23 15:55:39');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (16, '600', 'uca', 'fffff', '$2y$10$jIhmTHOAwdB..8fR2upMR.7q8u4c9W8v7G3Oa369o1LYOw2WLzbHG', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-23 15:55:39', '2025-04-23 15:55:39');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (17, '001', 'Admin', 'admin', '$2y$10$LqduT94lvIpy70RFV.Dwbu02YPMzmYAoHn/1oMZxygrj2xJn4L1Lm', '08123456789', 'Alamat Admin', '0.00', '0.00', 'aktif', 'admin', '2025-04-24 05:42:32', '2025-04-24 05:42:32');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (18, 'kk100', 'orang1', 'gg', '$2y$10$yK3h5JBS0Q2UsL7MchTjIOgLO8pfu6P0hUGmS6LafWwayAUSRJeem', 'Karyawan', NULL, '200.00', '0.00', 'aktif', 'karyawan', '2025-04-24 22:14:09', '2025-04-28 07:31:24');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (19, 'kk200', 'orang2', 'hh', '$2y$10$rG//86GDqUlwPl4psRbv..8PQEi0Vb/Q62T0EqBUuTbmGOMPvzQSO', 'Admin', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-24 22:14:09', '2025-04-27 20:33:37');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (20, 'kk300', 'orang3', 'ii', '$2y$10$JiXfw22TaOqT2NKqOwHnE.twHyn3tuEzgjQw.IdyeTiVBciw8PAM6', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-24 22:14:09', '2025-04-24 22:14:09');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (21, 'kk400', 'orang4', 'jj', '$2y$10$6249JCdw0XVT01C.JNTmAudRowicebf3e0C0Ur1Cp4pguxfGrCYGG', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-24 22:14:09', '2025-04-24 22:14:09');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (22, 'kk500', 'orang5', 'kk', '$2y$10$KorsCZPakgMhovPxZiR6wOLX3DlUlx09E0ihgQqWGw7HFD8IJXno2', 'Admin', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-24 22:14:09', '2025-04-24 22:14:09');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (23, 'kk600', 'orang6', 'll', '$2y$10$C1sxQKMTSX20l78pOGJHSu.rTea10Ymgd929q/l8Zq6VlnO/tuls.', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-24 22:14:09', '2025-04-24 22:14:09');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (24, '2025', 'Pak Herdi', 'Herdi', '$2y$10$44kBBj4iTX0H2z95S5mau.QrICNjVgK/N4rmmZ4HpxrVC7mvrMcXC', '09876544321', 'jl.kujang ', '0.00', '0.00', 'aktif', 'karyawan', '2025-04-26 20:30:33', '2025-04-26 20:30:33');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (25, 'KK01', 'Kawasaki', 'Kawasaki', '$2y$10$ux6OF0Gs8eTHyIG7lA8gcOFJbSVlbW6avs2qByZikLg6Dyxf0/FBG', 'Karyawan', NULL, '200.00', '100.00', 'aktif', 'karyawan', '2025-04-26 20:36:32', '2025-04-28 07:31:15');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (26, 'KK02', 'Ninja', 'Ninja', '$2y$10$qfg05j1j/j09RImwX499huVd89WJNdxyt37cCku0xk5jN.BA0pBNa', 'Admin', NULL, '50.00', '60.00', 'aktif', 'karyawan', '2025-04-26 20:36:32', '2025-04-28 07:34:27');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (27, 'KK03', 'Vespa', 'Vespa', '$2y$10$Snfif4fLIpfhhV9scE3WQul4xeTZw2PbO4uIWve4CGdsDo8hrpOLK', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-26 20:36:32', '2025-04-26 20:36:32');
INSERT INTO `karyawan` (`id`, `nik`, `nama_karyawan`, `username`, `password`, `no_hp`, `alamat`, `saldo_kasbon`, `saldo_tabungan`, `status`, `role`, `tanggal_buat`, `tanggal_update`) VALUES (28, 'KK04', 'Supra', 'Supra', '$2y$10$eJfnYnp8YS6NtTvFT2eNnuNitY1Z8fQ1WNz7v3bt4sXSeXMjSWcwe', 'Karyawan', NULL, '0.00', '0.00', 'aktif', 'karyawan', '2025-04-26 20:36:32', '2025-04-26 20:36:32');


#
# TABLE STRUCTURE FOR: kasbon
#

DROP TABLE IF EXISTS `kasbon`;

CREATE TABLE `kasbon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_karyawan` int NOT NULL,
  `tanggal` date NOT NULL,
  `jenis` enum('pinjam','bayar') COLLATE utf8mb4_general_ci NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `keterangan` text COLLATE utf8mb4_general_ci,
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `kasbon_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `kasbon` (`id`, `id_karyawan`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (9, 18, '2025-04-26', 'pinjam', '100.00', 'Buat Sekolah', '2025-04-26 22:19:30', '2025-04-26 23:05:22');
INSERT INTO `kasbon` (`id`, `id_karyawan`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (12, 25, '2025-04-27', 'pinjam', '200.00', 'asdj', '2025-04-27 20:32:55', '2025-04-27 20:32:55');
INSERT INTO `kasbon` (`id`, `id_karyawan`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (13, 26, '2025-04-28', 'pinjam', '50.00', 'buat beli laptop', '2025-04-28 07:31:45', '2025-04-28 07:31:45');


#
# TABLE STRUCTURE FOR: pekerjaan
#

DROP TABLE IF EXISTS `pekerjaan`;

CREATE TABLE `pekerjaan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_pekerjaan` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `harga_koperasi` decimal(15,2) NOT NULL,
  `harga_karyawan` decimal(15,2) NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_general_ci DEFAULT 'aktif',
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (1, 'Perbaikan atap', '200000.00', '175000.00', 'aktif', '2025-04-20 11:17:49', '2025-04-20 12:50:19');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (2, 'Perbaiki WC', '250000.00', '200000.00', 'aktif', '2025-04-20 12:31:26', '2025-04-20 12:31:26');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (3, 'cuci mobil', '200000.00', '175000.00', 'aktif', '2025-04-23 22:36:47', '2025-04-23 22:36:47');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (5, 'BERSIHIN KOLAM', '200000.00', '175000.00', 'aktif', '2025-04-23 23:00:47', '2025-04-23 23:00:47');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (6, 'BERSIHIN PT', '250000.00', '200000.00', 'aktif', '2025-04-23 23:00:47', '2025-04-23 23:00:47');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (9, 'angkat angkat', '250000.00', '200000.00', 'aktif', '2025-04-23 23:18:03', '2025-04-23 23:18:03');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (10, 'Bengkel mobil', '200000.00', '175000.00', 'aktif', '2025-04-23 23:35:04', '2025-04-23 23:35:04');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (11, 'angkat barang', '250000.00', '200000.00', 'aktif', '2025-04-23 23:35:04', '2025-04-23 23:35:04');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (13, 'Cuci Ban', '50000.00', '40000.00', 'aktif', '2025-04-26 20:59:41', '2025-04-26 20:59:41');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (14, 'Cuci Hewan', '25000.00', '20000.00', 'aktif', '2025-04-26 20:59:41', '2025-04-26 20:59:41');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (15, 'Potong Sapi', '50.00', '50.00', 'aktif', '2025-04-28 08:35:58', '2025-04-28 08:35:58');
INSERT INTO `pekerjaan` (`id`, `nama_pekerjaan`, `harga_koperasi`, `harga_karyawan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (16, 'Potong Sapi', '50.00', '50.00', 'aktif', '2025-04-28 08:58:16', '2025-04-28 08:58:16');


#
# TABLE STRUCTURE FOR: pendapatan
#

DROP TABLE IF EXISTS `pendapatan`;

CREATE TABLE `pendapatan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_karyawan` int NOT NULL,
  `tanggal` date NOT NULL,
  `total_pendapatan` decimal(15,2) DEFAULT '0.00',
  `status` enum('pending','selesai') COLLATE utf8mb4_general_ci DEFAULT 'pending',
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `pendapatan_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pendapatan` (`id`, `id_karyawan`, `tanggal`, `total_pendapatan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (9, 4, '2025-04-20', '3500000.00', '', '2025-04-20 19:40:42', '2025-04-26 22:00:56');
INSERT INTO `pendapatan` (`id`, `id_karyawan`, `tanggal`, `total_pendapatan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (12, 25, '2025-04-27', '1000000.00', '', '2025-04-27 01:13:58', '2025-04-27 01:13:58');
INSERT INTO `pendapatan` (`id`, `id_karyawan`, `tanggal`, `total_pendapatan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (13, 26, '2025-04-28', '175000.00', '', '2025-04-28 07:30:36', '2025-04-28 07:30:36');
INSERT INTO `pendapatan` (`id`, `id_karyawan`, `tanggal`, `total_pendapatan`, `status`, `tanggal_buat`, `tanggal_update`) VALUES (14, 26, '2025-04-28', '50.00', '', '2025-04-28 08:59:35', '2025-04-28 08:59:35');


#
# TABLE STRUCTURE FOR: pendapatan_detail
#

DROP TABLE IF EXISTS `pendapatan_detail`;

CREATE TABLE `pendapatan_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_pendapatan` int NOT NULL,
  `id_pekerjaan` int NOT NULL,
  `banyak` int NOT NULL,
  `harga_koperasi` decimal(15,2) NOT NULL,
  `harga_karyawan` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pendapatan` (`id_pendapatan`),
  KEY `id_pekerjaan` (`id_pekerjaan`),
  CONSTRAINT `pendapatan_detail_ibfk_1` FOREIGN KEY (`id_pendapatan`) REFERENCES `pendapatan` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pendapatan_detail_ibfk_2` FOREIGN KEY (`id_pekerjaan`) REFERENCES `pekerjaan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (15, 9, 1, 20, '200000.00', '175000.00', '3500000.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (16, 9, 2, 0, '250000.00', '200000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (17, 9, 3, 0, '200000.00', '175000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (18, 9, 5, 0, '200000.00', '175000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (19, 9, 6, 0, '250000.00', '200000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (20, 9, 9, 0, '250000.00', '200000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (21, 9, 10, 0, '200000.00', '175000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (22, 9, 11, 0, '250000.00', '200000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (24, 9, 13, 0, '50000.00', '40000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (25, 9, 14, 0, '25000.00', '20000.00', '0.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (26, 12, 6, 5, '250000.00', '200000.00', '1000000.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (27, 13, 10, 1, '200000.00', '175000.00', '175000.00');
INSERT INTO `pendapatan_detail` (`id`, `id_pendapatan`, `id_pekerjaan`, `banyak`, `harga_koperasi`, `harga_karyawan`, `total`) VALUES (28, 14, 15, 1, '50.00', '50.00', '50.00');


#
# TABLE STRUCTURE FOR: pengaturan
#

DROP TABLE IF EXISTS `pengaturan`;

CREATE TABLE `pengaturan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_koperasi` varchar(255) NOT NULL,
  `potongan_bpjs` decimal(5,2) DEFAULT '3.00',
  `uang_makan` decimal(15,2) NOT NULL DEFAULT '20000.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `pengaturan` (`id`, `nama_koperasi`, `potongan_bpjs`, `uang_makan`) VALUES (1, 'hugo', '0.09', '10.00');


#
# TABLE STRUCTURE FOR: slip_gaji
#

DROP TABLE IF EXISTS `slip_gaji`;

CREATE TABLE `slip_gaji` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_karyawan` int NOT NULL,
  `bulan` varchar(7) COLLATE utf8mb4_general_ci NOT NULL,
  `total_pendapatan` decimal(15,2) DEFAULT '0.00',
  `uang_makan` decimal(10,2) DEFAULT '0.00',
  `total_kasbon` decimal(15,2) DEFAULT '0.00',
  `total_tabungan` decimal(15,2) DEFAULT '0.00',
  `potongan_bpjs` decimal(5,2) NOT NULL DEFAULT '0.00',
  `gaji_bersih` decimal(15,2) DEFAULT '0.00',
  `catatan` text COLLATE utf8mb4_general_ci,
  `tanggal_cetak` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_slip` (`id_karyawan`,`bulan`),
  CONSTRAINT `slip_gaji_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `slip_gaji` (`id`, `id_karyawan`, `bulan`, `total_pendapatan`, `uang_makan`, `total_kasbon`, `total_tabungan`, `potongan_bpjs`, `gaji_bersih`, `catatan`, `tanggal_cetak`) VALUES (5, 2, '2025-04', '6550000.00', '0.00', '200200.00', '100000.00', '0.00', '6053300.00', '', '2025-04-24 03:42:15');
INSERT INTO `slip_gaji` (`id`, `id_karyawan`, `bulan`, `total_pendapatan`, `uang_makan`, `total_kasbon`, `total_tabungan`, `potongan_bpjs`, `gaji_bersih`, `catatan`, `tanggal_cetak`) VALUES (7, 4, '2025-04', '5650000.00', '0.00', '10000.00', '100000.00', '0.00', '5370500.00', 'Kerja bagus ', '2025-04-26 06:51:18');
INSERT INTO `slip_gaji` (`id`, `id_karyawan`, `bulan`, `total_pendapatan`, `uang_makan`, `total_kasbon`, `total_tabungan`, `potongan_bpjs`, `gaji_bersih`, `catatan`, `tanggal_cetak`) VALUES (16, 25, '2025-04', '1000000.00', '10.00', '200.00', '100.00', '900.00', '998810.00', 'wow', '2025-04-28 07:15:09');
INSERT INTO `slip_gaji` (`id`, `id_karyawan`, `bulan`, `total_pendapatan`, `uang_makan`, `total_kasbon`, `total_tabungan`, `potongan_bpjs`, `gaji_bersih`, `catatan`, `tanggal_cetak`) VALUES (18, 26, '2025-04', '175050.00', '20.00', '50.00', '60.00', '157.54', '174802.46', '', '2025-04-28 09:01:43');


#
# TABLE STRUCTURE FOR: tabungan
#

DROP TABLE IF EXISTS `tabungan`;

CREATE TABLE `tabungan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_karyawan` int NOT NULL,
  `tanggal` date NOT NULL,
  `jenis` enum('setor','tarik') COLLATE utf8mb4_general_ci NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `keterangan` text COLLATE utf8mb4_general_ci,
  `tanggal_buat` datetime DEFAULT CURRENT_TIMESTAMP,
  `tanggal_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_karyawan` (`id_karyawan`),
  CONSTRAINT `tabungan_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tabungan` (`id`, `id_karyawan`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (1, 2, '2025-04-20', 'setor', '100000.00', 'Buat Sekolah', '2025-04-20 14:19:29', '2025-04-26 23:06:34');
INSERT INTO `tabungan` (`id`, `id_karyawan`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (3, 25, '2025-04-27', 'setor', '100.00', 'buat nabung mobil', '2025-04-27 14:00:43', '2025-04-27 14:00:43');
INSERT INTO `tabungan` (`id`, `id_karyawan`, `tanggal`, `jenis`, `jumlah`, `keterangan`, `tanggal_buat`, `tanggal_update`) VALUES (4, 26, '2025-04-28', 'setor', '60.00', 'Buat Jajan', '2025-04-28 07:34:27', '2025-04-28 07:34:27');


